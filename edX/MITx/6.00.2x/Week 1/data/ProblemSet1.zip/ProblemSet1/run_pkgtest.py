# Import the package test - graph should pop up if Pylab and NumPy
# are properly installed.
import ps1_pkgtest
